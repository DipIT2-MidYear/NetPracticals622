from netmiko import ConnectHandler
print("starting connection test...")
device = {"device_type":"cisco_ios", "host":"192.168.1.1", "username":"admin", "password":"admin",}
try:
    connection = ConnectHandler(**device)
    print("Connected Successfully!")
    output = connection.disconnect()
except Exception as e:
    print("Connection failed:")
    print(e)